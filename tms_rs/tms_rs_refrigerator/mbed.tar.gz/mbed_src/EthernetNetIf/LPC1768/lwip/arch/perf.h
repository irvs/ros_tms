/*
 * Author: Adam Dunkels <adam@sics.se>
 *
 */
#ifndef __LWIP_ARCH_PERF_H__
#define __LWIP_ARCH_PERF_H__

#define PERF_START
#define PERF_STOP(x)

#define perf_init(fname)

#if 0
#ifdef __cplusplus
inline
#endif
void perf_init(char *fname) {
  return;  
}
#endif


#endif /* __LWIP_ARCH_PERF_H__ */
